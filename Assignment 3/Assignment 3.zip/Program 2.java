package PracticeAssignment;
import java.util.ArrayList;
import java.util.List;


public class Program2_2 {	
		
	 public static void main(String args[]) 
	    { 
	 
	        List<String>list1 = new ArrayList <String>(); 
	  
	        list1.add("Darshan"); 
	        list1.add("Rahul");
	        list1.add("Himani"); 
	        list1.add("Dipika");
	        list1.add("Ronak");
	  
	       
	        System.out.println("Name List 1: " + list1); 
	 
	        List<String>list2= new ArrayList <String>(); 
	  	  
	        list2.add("Biren"); 
	        list2.add("Himanshu");
	        list2.add("Kartik"); 
	        list2.add("Madhuri");
	        list2.add("Unnati");
	        
	        System.out.println("\nName List 2: "+ list2);
	        
	        System.out.println();
	        System.out.println("After Adding List1 with List2:\n"); 
	 
	        list1.addAll(list2);
	
	        System.out.println("All QA Names are: " + list1); 
	    } 
	} 