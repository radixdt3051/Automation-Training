package PracticeAssignment;

import java.util.Arrays;

public class Program2_1 {

    public static void main(String[] args) {
    	
    	
    	
    	int[] Price = {0,1,2,3,4,5};
    	int[] Quantity = {0,1,2,3,4,5};
    	String[] Size = {"5x5","5x10","10x10","10x15","15x15"};
		
	
		System.out.println("Product Prices are: " + Arrays.toString(Price));
		System.out.println("\nProduct Quantities are:  " + Arrays.toString(Quantity));
		System.out.println("\nProduct Sizes are:  " + Arrays.deepToString(Size));
	
    	
    }
    	
    }
    
  
 // Another way to write program,
    
    
  /*    int[] Price = new int[5];
        int[] Quantity = new int[5];
        String[] Size = new String[5];

        Price[0] = 10;
        Price[1] = 20;
        Price[2] = 30;
        Price[3] = 40;
        Price[4] = 50;

        Quantity[0] = 100;
        Quantity[1] = 200;
        Quantity[2] = 300;
        Quantity[3] = 400;
        Quantity[4] = 500;

        Size[0] = "5x5";
        Size[1] = "5x10";
        Size[2] = "10x10";
        Size[3] = "10x15";
        Size[4] = "15x15";
        
        System.out.println("Product Prices are: ");
        for (int i = 0; i < Price.length; i++) {
            System.out.println( Price[i]);
        }
        System.out.println();
        System.out.println("Product Quantities are: ");
        for (int i = 0; i < Quantity.length; i++) {
            System.out.println( Quantity[i]);
        }
        System.out.println();
        System.out.println("Product Sizes are: ");
        for (int i = 0; i < Size.length; i++) {
            System.out.println(Size[i]);
        }
    }
  }
*/
    	
    	