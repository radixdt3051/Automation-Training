package PracticeAssignment;
import java.util.Scanner;

public class Program2_3 {
	

	public static void main(String[] args) {
		String n;
		
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter your Full Name: ");
		n = sc.nextLine();
		String [] s = n.split(" ");
		int a = s.length;
		
		System.out.print("Result: ");
		for(int i=0; i<a-1;i++) {
			System.out.print(s[i].charAt(0)+ ".");
		}
			System.out.print(s[a-1]);
	}
	
}
	
	
// Another way to write this program,

/*	    public static void main(String[] args) {
	        @SuppressWarnings("resource")
			Scanner input = new Scanner(System.in);
	        
	        System.out.println("Please enter your full name: ");
	        String fullName = input.nextLine();
	        
	     	String[] names = fullName.split(" ");
	        String firstName = names[0];
	        String middleName = names[1];
	        String lastName = names[2];
	        
	        char firstInitial = firstName.charAt(0);
	        char middleInitial = middleName.charAt(0);
	        
	        System.out.println(firstInitial + "." + middleInitial + "." + lastName);
	    }
	}

	*/
	