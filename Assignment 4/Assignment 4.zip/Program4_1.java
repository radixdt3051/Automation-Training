package PracticeAssignment;

import java.util.Scanner;


abstract class Marks {
	
	abstract public double getPercenteage();

}

class StudentA extends Marks {
	
	double subject1;
	double subject2;
	double subject3;
	
	public StudentA (double subject1, double subject2, double subject3) {
		
		this.subject1 = subject1;
		this.subject2 = subject2;
		this.subject3 = subject3;
	}

	public double getPercenteage() {
		
		double TotalMarks = subject1 + subject2 + subject3;
		return TotalMarks = (TotalMarks/300 * 100);
	}

}

class StudentB extends Marks {
	
	double subject1;
	double subject2;
	double subject3;
	double subject4;
	
	public StudentB (double subject1, double subject2, double subject3, double subject4) {
		
		this.subject1 = subject1;
		this.subject2 = subject2;
		this.subject3 = subject3;
		this.subject4 = subject4;
	}


	public double getPercenteage() {
		
		double TotalMarks = subject1 + subject2 + subject3 + subject4;
		return TotalMarks = (TotalMarks/400 * 100);

	}
	
}

public class Program4_1 {
	
	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Marks of Student A: ");
		
		double Marks1 = sc.nextDouble();
		double Marks2 = sc.nextDouble();
		double Marks3 = sc.nextDouble();
		StudentA studentA = new StudentA(Marks1, Marks2, Marks3);
		
		System.out.println("Enter Marks of Student B: ");
		double Marks4 = sc.nextDouble();
		double Marks5 = sc.nextDouble();
		double Marks6 = sc.nextDouble();
		double Marks7 = sc.nextDouble();
		StudentB studentB = new StudentB(Marks4, Marks5, Marks6, Marks7);
		
		System.out.println(studentA.getPercenteage());
		
		System.out.println(studentB.getPercenteage());
		
	}
}