package PracticeAssignment;

	class Bank {
		
		float ROI()
		{
			return 0;
		}
	}
	
	class SBI extends Bank {
		float ROI()
		{
			return 8.1f;
		}
	}
	
	class ICICI extends Bank {
		float ROI()
		{
			return 8.5f;
		}
	}
	
	class AXIS extends Bank {
		float ROI()
		{
			return 9.1f;
		}
	}
	
	class Program4_2 {
		
		public static void main(String[] args) {
			
			Bank B;
			
			B = new SBI();
			System.out.println("SBI Bank Home Loan Interest Rate is: " + B.ROI());

			B = new ICICI();
			System.out.println("ICICI Bank Home Loan Interest Rate is: " + B.ROI());
			
			B = new AXIS();
			System.out.println("AXIS Bank Home Loan Interest Rate is: " + B.ROI());
	}
}